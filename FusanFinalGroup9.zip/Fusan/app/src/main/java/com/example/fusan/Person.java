package com.example.fusan;

import android.graphics.Bitmap;

public class Person {
    public String face;
    public String person;
    public String time;


    public Person(String face, String person,String time){
        this.face = face;
        this.person = person;
        this.time = time;
    }
}
